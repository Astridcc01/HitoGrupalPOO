package com.variables2;

import com.variables.Variable1;
import com.variables.Variable2;
import com.variables.Variable3;

public class Principal {
	public static void main(String[] args) {
		//public
	Variable1 variable1=new Variable1(true,4,3.14,4.5,'a',"hola");
		//protected
	Variable2 variable2=new Variable2(true,4,3.14,4.5,'a',"hola");
		//private
	Variable3 variable3=new Variable3(true,4,3.14,4.5,'a',"hola");
	}
}
