
public class Futbol extends Deporte {
	
	//CONSTRUCTOR
	public Futbol(String balon, int piernas) {
		super(balon, piernas);
	}

	//M�TODOS
	public void Jugar(){
		System.out.println("Doy patadas al bal�n");
	}
}
